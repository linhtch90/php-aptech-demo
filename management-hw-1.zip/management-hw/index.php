<?php

include "./model/supplier.php";
include "./model/employee.php";
include "./model/customer.php";

include "./service/supplierService.php";
include "./service/employeeService.php";
include "./service/customerService.php";

if (!isset($_GET["action"])) {

    // supplier

    header("Location: ./view/supplierView.php");
} else if ($_GET["action"] == "addSupplierForm") {
    header("Location: ./view/addSupplierForm.php");
} else if ($_GET["action"] == "addSupplier") {
    $supplier = new Supplier($_POST["name"], $_POST["email"], $_POST["phoneNumber"], $_POST["address"]);
    insertSupplier($supplier);
    header("Location: ./view/supplierView.php");
} else if ($_GET["action"] == "deleteSupplier") {
    $result = deleteSupplier((int)$_GET["id"]);
    header("Location: ./view/supplierView.php");
} else if ($_GET["action"] == "updateSupplierForm") {
    header("Location: ./view/updateSupplierForm.php?id={$_GET["id"]}");
} else if ($_GET["action"] == "updateSupplier") {
    $supplier = new Supplier($_POST["name"], $_POST["email"], $_POST["phoneNumber"], $_POST["address"]);
    updateSupplier($supplier, $_GET["id"]);
    header("Location: ./view/supplierView.php");
} else if ($_GET["action"] == "employeeView") {

    // employee

    header("Location: ./view/employeeView.php");
} else if ($_GET["action"] == "employeeAddForm") {
    header("Location: ./view/employeeAddForm.php");
} else if ($_GET["action"] == "employeeAdd") {
    $rawdate = htmlentities($_POST["birthday"]);
    $birthday = date("Y-m-d", strtotime($rawdate));
    $employee = new Employee($_POST["firstName"], $_POST["lastName"], $_POST["email"], $_POST["phoneNumber"], $_POST["address"], $birthday);
    insertEmployee($employee);
    header("Location: ./view/employeeView.php");
} else if ($_GET["action"] == "employeeDelete") {
    deleteEmployee($_GET["id"]);
    header("Location: ./view/employeeView.php");
} else if ($_GET["action"] == "employeeUpdateForm") {
    header("Location: ./view/employeeUpdateForm.php?id={$_GET["id"]}");
} else if ($_GET["action"] == "employeeUpdate") {
    $rawdate = htmlentities($_POST["birthday"]);
    $birthday = date("Y-m-d", strtotime($rawdate));
    $employee = new Employee($_POST["firstName"], $_POST["lastName"], $_POST["email"], $_POST["phoneNumber"], $_POST["address"], $birthday);
    updateEmployee($employee, $_GET["id"]);
    header("Location: ./view/employeeView.php");
} else if ($_GET["action"] == "customerView") {

    // customer

    header("Location: ./view/customerView.php");
} else if ($_GET["action"] == "customerAddForm") {
    header("Location: ./view/customerAddForm.php");
} else if ($_GET["action"] == "customerAdd") {
    $rawdate = htmlentities($_POST["birthday"]);
    $birthday = date("Y-m-d", strtotime($rawdate));
    $customer = new Customer($_POST["firstName"], $_POST["lastName"], $_POST["email"], $_POST["phoneNumber"], $_POST["address"], $birthday);
    insertCustomer($customer);
    header("Location: ./view/customerView.php");
} else if ($_GET["action"] == "customerDelete") {
    deleteCustomer($_GET["id"]);
    header("Location: ./view/customerView.php");
} else if ($_GET["action"] == "customerUpdateForm") {
    header("Location: ./view/customerUpdateForm.php?id={$_GET["id"]}");
} else if ($_GET["action"] == "customerUpdate") {
    $rawdate = htmlentities($_POST["birthday"]);
    $birthday = date("Y-m-d", strtotime($rawdate));
    $customer = new Customer($_POST["firstName"], $_POST["lastName"], $_POST["email"], $_POST["phoneNumber"], $_POST["address"], $birthday);
    updateCustomer($customer, $_GET["id"]);
    header("Location: ./view/customerView.php");
}
